package com.example.myapplicationds

data class RetrofitModel(
    var id: Int = 0,
    var title: String = "",
    var bode: String = ""
)