package com.example.myapplicationds

import io.reactivex.rxjava3.core.Single
import retrofit2.http.GET

interface RetrofitServices {
    @GET("posts")
    fun getMovieList(): Single<MutableList<RetrofitModel>>
}