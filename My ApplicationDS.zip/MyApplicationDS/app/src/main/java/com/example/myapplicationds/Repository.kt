package com.example.myapplicationds

class Repository {

}